Paste the MODS FOLDER To Your .minecraft directory and then launch fabric api 1.21.1
------TUTORIAL----------------------------------------------------------------------
Video Link: https://youtu.be/F4JgDknqk1I?si=EQwuOR8ox-iBD6_u